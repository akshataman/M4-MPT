package PaymentDetails;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pageBean.PaymentDetailsPageFactory;

public class PaymentDetailsStepDefinition {

	private WebDriver driver;
	private PaymentDetailsPageFactory detailsPageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Selenium\\chromedriver_win32\\chromedriver.exe" );	
				driver= new ChromeDriver();
	}
	
	 @Given("^user is on 'Payment' page$")
	 public void user_is_on_Payment_page() throws Throwable {
	 driver.get("D:\\Users\\akaman\\Selenium_Workspace\\PanRegistration\\PaymentDetails.html");
	 detailsPageFactory= new PaymentDetailsPageFactory(driver);
	 }

	 @When("^user enters invalid Card Holder Name$")
	 public void user_enters_invalid_Card_Holder_Name() throws Throwable {
	 detailsPageFactory.setCardholderName("");
	 detailsPageFactory.setPaymentbutton();
	 }

	 @Then("^displays 'Please fill the Card Holder Name'$")
	 public void displays_Please_fill_the_Card_Holder_Name() throws Throwable {
	 String expectedMessage="Please fill the Card holder name";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters invalid Debit Card Number$")
	 public void user_enters_invalid_Debit_Card_Number() throws Throwable {
	 detailsPageFactory.setCardholderName("Akshat Aman");
	 detailsPageFactory.setDebitno("");
	 detailsPageFactory.setPaymentbutton();
	 }

	 @Then("^displays 'Please fill Debit Card Number'$")
	 public void displays_Please_fill_Debit_Card_Number() throws Throwable {	  
	 String expectedMessage="Please fill the Debit card Number";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user does not enter CVV value$")
	 public void user_does_not_enter_CVV_value() throws Throwable {
	 detailsPageFactory.setCardholderName("Akshat Aman");
	 detailsPageFactory.setDebitno("1234-4321-1234-5678");
	 detailsPageFactory.setCvvno("");
	 detailsPageFactory.setPaymentbutton();
	 }

	 @Then("^displays 'Please fill CVV Number'$")
	 public void displays_Please_fill_CVV_Number() throws Throwable {
	 String expectedMessage="Please fill the CVV";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters invalid Expiration Month$")
	 public void user_enters_invalid_Expiration_Month() throws Throwable {
	 detailsPageFactory.setCardholderName("Akshat Aman");
	 detailsPageFactory.setDebitno("1234-4321-1234-5678");
	 detailsPageFactory.setCvvno("123");
	 detailsPageFactory.setMonthname("");
	 detailsPageFactory.setPaymentbutton();
	 }
	 
	 @Then("^displays 'Please fill Expiration Month'$")
	 public void displays_Please_fill_Expiration_Month() throws Throwable {
	 String expectedMessage="Please fill expiration month";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters invalid Expiration Year$")
	 public void user_enters_invalid_Expiration_Year() throws Throwable {
	 detailsPageFactory.setCardholderName("Akshat Aman");
	 detailsPageFactory.setDebitno("1234-4321-1234-5678");
	 detailsPageFactory.setCvvno("123");
	 detailsPageFactory.setMonthname("04");
	 detailsPageFactory.setExpiryyear("");
	 detailsPageFactory.setPaymentbutton();
	 }

	 @Then("^displays 'Please fill Expiration Year'$")
	 public void displays_Please_fill_Expiration_Year() throws Throwable {
	 String expectedMessage="Please fill the expiration year";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters valid Payment Details$")
	 public void user_enters_valid_Payment_Details() throws Throwable {
	 detailsPageFactory.setCardholderName("Akshat Aman");
	 detailsPageFactory.setDebitno("1234-4321-1234-5678");
	 detailsPageFactory.setCvvno("123");
	 detailsPageFactory.setMonthname("04");
	 detailsPageFactory.setExpiryyear("32");
	 detailsPageFactory.setPaymentbutton();
	 }

	 @Then("^displays 'Pan Card Registration Done Successfully !!!'$")
	 public void displays_Pan_Card_Registration_Done_Successfully() throws Throwable {
	 }

}

