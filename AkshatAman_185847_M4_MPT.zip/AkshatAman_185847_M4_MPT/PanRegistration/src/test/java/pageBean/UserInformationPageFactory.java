package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UserInformationPageFactory {

	WebDriver driver;

	//step 1 : identify elements
	@FindBy(name="txtNM")
	@CacheLookup
	WebElement applicantName;
	
	@FindBy(name="txtFName")
	@CacheLookup
	WebElement firstName;

	@FindBy(name="txtLName")
	@CacheLookup
	WebElement lastName;

	@FindBy(name="txtFtName")
	@CacheLookup
	WebElement fatherName;

	@FindBy(name="txtDOB")
	@CacheLookup
	WebElement dob;

	@FindBy(name="rdbFML")
	@CacheLookup
	WebElement gender;

	@FindBy(name="txtMNo")
	@CacheLookup
	WebElement mobileno;

	@FindBy(name="txtEmailID")
	@CacheLookup
	WebElement mailId;
	
	@FindBy(name="txtLLine")
	@CacheLookup
	WebElement landline;

	@FindBy(name="rdbOffAddress")
	@CacheLookup
	WebElement communication;

	@FindBy(name="resAddress")
	@CacheLookup
	WebElement address;

	@FindBy(name="bnSubmit")
	@CacheLookup
	WebElement submitbutton;

	public WebDriver getDriver() {
	return driver;
	}

	public void setDriver(WebDriver driver) {
	this.driver = driver;
	}

	public WebElement getApplicantName() {
	return applicantName;
	}

	public void setApplicantName(String applicantName) {
	this.applicantName.sendKeys(applicantName);
	}

	public WebElement getFirstName() {
	return firstName;
	}

	public void setFirstName(String firstName) {
	this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
	return lastName;
	}

	public void setLastName(String lastName) {
	this.lastName.sendKeys(lastName);
	}

	public WebElement getFatherName() {
	return fatherName;
	}

	public void setFatherName(String fatherName) {
	this.fatherName.sendKeys(fatherName);
	}

	public WebElement getDob() {
	return dob;
	}
	
	public void setDob(String dob) {
	this.dob.sendKeys(dob);
	}

	public WebElement getGender() {
	return gender;
	}

	public void setGender(String gender) {
	this.gender.sendKeys(gender);
	}

	public WebElement getMobileno() {
	return mobileno;
	}

	public void setMobileno(String mobileno) {
	this.mobileno.sendKeys(mobileno);
	}

	public WebElement getMailId() {
	return mailId;
	}

	public void setMailId(String mailId) {
	this.mailId.sendKeys(mailId);
	}

	public WebElement getLandline() {
	return landline;
	}
	
	public void setLandline(String landline) {
	this.landline.sendKeys(landline);
	}

	public WebElement getCommunication() {
	return communication;
	}

	public void setCommunication(String communication) {
	this.communication.sendKeys(communication);
	}

	public WebElement getAddress() {
	return address;
	}

	public void setAddress(String address) {
	this.address.sendKeys(address);
	}

	public WebElement getSubmitbutton() {
	return submitbutton;
	}

	public void setSubmitbutton() {
	this.submitbutton.click();
	}

	//initiating Elements
	public UserInformationPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		}
	}

