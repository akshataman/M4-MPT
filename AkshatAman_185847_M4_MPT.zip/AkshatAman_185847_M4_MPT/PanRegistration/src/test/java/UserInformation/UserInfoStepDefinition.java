package UserInformation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pageBean.UserInformationPageFactory;


public class UserInfoStepDefinition {
	private WebDriver driver;
	private UserInformationPageFactory infoPageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Selenium\\chromedriver_win32\\chromedriver.exe" );
				driver= new ChromeDriver();
	}
	
	 @Given("^user is on 'PanRegistration' page$")
	 public void user_is_on_PanRegistration_page() throws Throwable {
	 driver.get("D:\\Users\\akaman\\Selenium_Workspace\\PanRegistration\\UserInformation.html");
	 infoPageFactory= new UserInformationPageFactory(driver);
	 }

	 @When("^user enters Invalid Applicant Name$")
	 public void user_enters_Invalid_Applicant_Name() throws Throwable {
	 infoPageFactory.setApplicantName("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^displays 'Please fill the Applicant Name'$")
	 public void displays_Please_fill_the_Applicant_Name() throws Throwable {
	 String expectedMessage="Please fill the Applicant Name";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters Invalid First Name$")
	 public void user_enters_Invalid_First_Name() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^displays 'Please fill the First Name$")
	 public void displays_Please_fill_the_First_Name() throws Throwable {
	 String expectedMessage="Please fill the First Name";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters Invalid Last Name$")
	 public void user_enters_Invalid_Last_Name() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^displays 'Please fill the Last Name'$")
	 public void displays_Please_fill_the_Last_Name() throws Throwable {
	 String expectedMessage="Please fill the Last Name";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters Invalid Father Name$")
	 public void user_enters_Invalid_Father_Name() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^displays 'Please fill the Father Name$")
	 public void displays_Please_fill_the_Father_Name() throws Throwable {
	 String expectedMessage="Please fill the Father Name";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters Invalid Date of Birth$")
	 public void user_enters_Invalid_Date_of_Birth() throws Throwable {	
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("Ajay Kumar Sinha");
	 infoPageFactory.setDob("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^displays 'Please enter Date of Birth'$")
	 public void displays_Please_enter_Date_of_Birth() throws Throwable {
	 String expectedMessage="Please fill the DOB";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters Invalid Date of Birth format$")
	 public void user_enters_Invalid_Date_of_Birth_format() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("Ajay Kumar Sinha");
	 infoPageFactory.setDob("25/04/1996");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^displays 'Please enter Date of Birth in dd-Mm-yyyy format'$")
	 public void displays_Please_enter_Date_of_Birth_in_dd_Mm_yyyy_format() throws Throwable {
	 String expectedMessage="Please Enter valid date(dd-MM-yyyy)";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user does not selects any Gender$")
	 public void user_does_not_selects_any_Gender() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("Ajay Kumar Sinha");
	 infoPageFactory.setDob("25/04/1996");
	 infoPageFactory.setGender("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^displays 'Please select the Gender'$")
	 public void displays_Please_select_the_Gender() throws Throwable {
	 String expectedMessage="Please select the Gender";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters invalid Mobile Number$")
	 public void user_enters_invalid_Mobile_Number() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("Ajay Kumar Sinha");
	 infoPageFactory.setDob("25/04/1996");
	 infoPageFactory.setGender("Male");
	 infoPageFactory.setMobileno("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^display 'Please fill the Mobile No\\.'$")
	 public void display_Please_fill_the_Mobile_No() throws Throwable {
	 String expectedMessage="Please fill Mobile no";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters wrong Mobile Number$")
	 public void user_enters_wrong_Mobile_Number() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("Ajay Kumar Sinha");
	 infoPageFactory.setDob("25/04/1996");
	 infoPageFactory.setGender("Male");
	 infoPageFactory.setMobileno("7224816164");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^display 'Please enter (\\d+) digit Mobile No\\.'$")
	 public void display_Please_enter_digit_Mobile_No(int arg1) throws Throwable {
	 String expectedMessage="Please enter valid mobile no";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }
	 
	 @When("^user enters Invalid Email$")
	 public void user_enters_Invalid_Email() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("Ajay Kumar Sinha");
	 infoPageFactory.setDob("25/04/1996");
	 infoPageFactory.setGender("Male");
	 infoPageFactory.setMobileno("7224816164");
	 infoPageFactory.setMailId("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^display 'Please fill the Mail Id'$")
	 public void display_Please_fill_the_Mail_Id() throws Throwable {
	 String expectedMessage="Please enter valid Email id";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters invalid Landline Number$")
	 public void user_enters_invalid_Landline_Number() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("Ajay Kumar Sinha");
	 infoPageFactory.setDob("25/04/1996");
	 infoPageFactory.setGender("Male");
	 infoPageFactory.setMobileno("7224816164");
	 infoPageFactory.setMailId("aman.akshat@gmail.com");
	 infoPageFactory.setLandline("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^display 'Please fill the Landline No\\.'$")
	 public void display_Please_fill_the_Landline_No() throws Throwable {
	 String expectedMessage="please fill the landline no";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user selects invalid communication$")
	 public void user_selects_invalid_communication() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("Ajay Kumar Sinha");
	 infoPageFactory.setDob("25/04/1996");
	 infoPageFactory.setGender("Male");
	 infoPageFactory.setMobileno("7224816164");
	 infoPageFactory.setMailId("akshat.aman@gmail.com");
	 infoPageFactory.setLandline("2240892");
	 infoPageFactory.setCommunication("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^display 'Please select Communication'$")
	 public void display_Please_select_Communication() throws Throwable {
	 String expectedMessage="Please select the Type of Communication ";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters invalid Address$")
	 public void user_enters_invalid_Address() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("Ajay Kumar Sinha");
	 infoPageFactory.setDob("25/04/1996");
	 infoPageFactory.setGender("Male");
	 infoPageFactory.setMobileno("7224816164");
	 infoPageFactory.setMailId("aman.akshat@gmail.com");
	 infoPageFactory.setLandline("2240892");
	 infoPageFactory.setCommunication("Office");
	 infoPageFactory.setAddress("");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^display 'Please enter the Address'$")
	 public void display_Please_enter_the_Address() throws Throwable {
	 String expectedMessage="please enter the Addresss";
	 String actualMessage=driver.switchTo().alert().getText();
	 Assert.assertEquals(expectedMessage, actualMessage);
	 driver.switchTo().alert().accept();
	 driver.close();
	 }

	 @When("^user enters valid personal details$")
	 public void user_enters_valid_personal_details() throws Throwable {
	 infoPageFactory.setApplicantName("Akshat Aman");
	 infoPageFactory.setFirstName("Akshat");
	 infoPageFactory.setLastName("Aman");
	 infoPageFactory.setFatherName("Ajay Kumar Sinha");
	 infoPageFactory.setDob("25/04/1996");
	 infoPageFactory.setGender("Male");
	 infoPageFactory.setMobileno("7224816164");
	 infoPageFactory.setMailId("aman.akshat@gmail.com");
	 infoPageFactory.setLandline("2240892");
	 infoPageFactory.setCommunication("Office");
	 infoPageFactory.setAddress("Pune");
	 infoPageFactory.setSubmitbutton();
	 }

	 @Then("^displays 'Personal Details are Validated '$")
	 public void displays_Personal_Details_are_Validated() throws Throwable {
	 driver.get("D:\\Users\\akaman\\Selenium_Workspace\\PanRegistration\\PaymentDetails.html");
	 driver.close();
	 }
	
}
